/*
 * Copyright 1993-2010 NVIDIA Corporation.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property and 
 * proprietary rights in and to this software and related documentation. 
 * Any use, reproduction, disclosure, or distribution of this software 
 * and related documentation without an express license agreement from
 * NVIDIA Corporation is strictly prohibited.
 *
 * Please refer to the applicable NVIDIA end user license agreement (EULA) 
 * associated with this source code for terms and conditions that govern 
 * your use of this NVIDIA software.
 * 
 */

#ifndef __BODYSYSTEMCPU_H__
#define __BODYSYSTEMCPU_H__

#include "bodysystem.h"

// CPU Body System
template <typename T>
class BodySystemCPU : public BodySystem<T>
{
public:
    BodySystemCPU(int numBodies);
    virtual ~BodySystemCPU();

    virtual void update(float deltaTime);

    virtual void setSoftening(float softening) { m_softeningSquared = softening * softening; }
    virtual void setDamping(float damping)     { m_damping = damping; }

    virtual T* getArray(BodyArray array);
    virtual void   setArray(BodyArray array, const T* data);

    virtual unsigned int getCurrentReadBuffer() const { return 0; }

    virtual unsigned int getNumBodies() const { return m_numBodies; }

protected: // methods
    BodySystemCPU() {} // default constructor

    virtual void _initialize(int numBodies);
    virtual void _finalize();

    void _computeNBodyGravitation();
    void _integrateNBodySystem(float deltaTime);
    
protected: // data
    int m_numBodies;
    bool         m_bInitialized;

    T* m_pos;
    T* m_vel;
    T* m_force;

    float m_softeningSquared;
    float m_damping;
};

#include "bodysystemcpu_impl.h"

#endif // __BODYSYSTEMCPU_H__
