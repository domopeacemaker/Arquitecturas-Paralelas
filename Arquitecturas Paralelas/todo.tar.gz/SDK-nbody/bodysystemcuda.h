/*
 * Copyright 1993-2010 NVIDIA Corporation.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property and 
 * proprietary rights in and to this software and related documentation. 
 * Any use, reproduction, disclosure, or distribution of this software 
 * and related documentation without an express license agreement from
 * NVIDIA Corporation is strictly prohibited.
 *
 * Please refer to the applicable NVIDIA end user license agreement (EULA) 
 * associated with this source code for terms and conditions that govern 
 * your use of this NVIDIA software.
 * 
 */

#ifndef __BODYSYSTEMCUDA_H__
#define __BODYSYSTEMCUDA_H__

#include "bodysystem.h"


// CUDA BodySystem: runs on the GPU
template <typename T>
class BodySystemCUDA : public BodySystem<T>
{
public:
    BodySystemCUDA(int numBodies, bool usePBO);
    BodySystemCUDA(int numBodies, unsigned int p, unsigned int q, bool usePBO, bool useSysMem = false);
    virtual ~BodySystemCUDA();

    virtual void update(float deltaTime);

    virtual void setSoftening(float softening);
    virtual void setDamping(float damping);

    virtual T* getArray(BodyArray array);
    virtual void   setArray(BodyArray array, const T* data);

    virtual unsigned int getCurrentReadBuffer() const 
    { 
        return m_pbo[m_currentRead]; 
    }

    virtual unsigned int getNumBodies() const { return m_numBodies; }

protected: // methods
    BodySystemCUDA() {}

    virtual void _initialize(int numBodies);
    virtual void _finalize();
    
protected: // data
    unsigned int m_numBodies;
    bool m_bInitialized;

    // CPU data
    T* m_hPos[2];
    T* m_hVel;

    // GPU data
    T* m_dPos[2];
    T* m_dVel;

    bool m_bUsePBO;
    bool m_bUseSysMem;
	unsigned int m_SMVersion;

    float m_damping;

    unsigned int m_pbo[2];
    cudaGraphicsResource* m_pGRes[2];
    unsigned int m_currentRead;
    unsigned int m_currentWrite;

    unsigned int m_p;
    unsigned int m_q;
};

#include "bodysystemcuda_impl.h"

#endif // __BODYSYSTEMCUDA_H__
